#include "npb-osap.h"

Osap::Osap(): NonPropertyBuilding{"OSAP", 0} {}

void Osap::event(Player * p) {

}
