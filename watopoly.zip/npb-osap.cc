#include "npb-osap.h"

Osap::Osap(): NonPropertyBuilding{"Collect OSAP", 0} {}

void Osap::event(Player * p) {

}
